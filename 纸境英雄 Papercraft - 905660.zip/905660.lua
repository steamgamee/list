addappid(905660)
addappid(905661, 1, "d1a743ebbb7faa4af00c27eb449ece997b4c4f6bdaac4a3bd5ed69f7f8ff1681")
setManifestid(905661, "3975040226689535735", 0)